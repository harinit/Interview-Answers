import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.junit.Test;

public class java5 {

	
	// Question 5 Time: n*n*n, Space: n*n
	
	int primes[] = new int[1024];
	int canshow[][] = new int[1024][1024];
	int calculated = 0;
	
	
	int min(int x, int y) {
		if(x < y) return x;
		return y;
	}
	
	int canshow(int x, int i, int height) throws IndexOutOfBoundsException {
		if(i < 2 || x < 2) return -1;
		if(primes[x] == 1 && x <= i && height == 1) {
			return canshow[x][i] = x;
		}
		if(canshow[x][i] != 0)
			return canshow[x][i];
		for(int j = i - 1; j >= 2; j--) {
			if(primes[j] == 1 && canshow(x - j, min(j - 1, x - j), 1) != -1) {
				return canshow[x][i] = j;
			}
		}
		return canshow[x][i]=-1;
	}
	void setPrime(int x) throws IndexOutOfBoundsException {
		if(x < 2) {
			return;
		}
		for(int i = 2; i * i <= x; i++)
			if(x % i == 0)
				return;
		primes[x] = 1;
	}
	
	List<Integer> sumOfPrimes(Integer number){
		List<Integer> retV = new ArrayList<Integer>();
		if(calculated == 0) {
			calculated = 1;
			for(int i = 0; i < 1024; i++) {
				setPrime(i);
			}
		}
		if(canshow(number, number, 0) == -1)
			return retV;
		int v = number, v2 = number;
		int height = 0;
		while(primes[v] != 1 || height == 0) {
			retV.add(canshow(v,v2, height));
			int temp = v;
			v -= canshow(v, v2,height);
			v2 = min(v2 - canshow(temp,v2,height), temp);
			height = 1;
		}
		retV.add(v);
		return retV;
	}

	public static void main(String[] args) {

		List<Integer> unsorted = new ArrayList<Integer>();
		
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter num : ");
		int n = reader.nextInt(); // Scans the next token of the input as an int.
		
		//once finished
		reader.close();
		
		java5 java = new java5();
		System.out.println(java.sumOfPrimes(n));
	}
}
