import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class java1Test {

	// Question1 Test
	@Test
	public void positive() throws IndexOutOfBoundsException {
		List<Integer> unsorted = new ArrayList<Integer>();
		unsorted.add(1);
		unsorted.add(7);
		unsorted.add(2);
		unsorted.add(3);
		unsorted.add(19);
		unsorted.add(5);
		java1 java = new java1();
		List<Integer> retV = java.funnySort(unsorted);
		assertEquals(6, retV.size());
		assertEquals(19, (int)retV.get(0));
		assertEquals(7, (int)retV.get(1));
		assertEquals(1, (int)retV.get(2));
		assertEquals(2, (int)retV.get(3));
		assertEquals(5, (int)retV.get(4));
		assertEquals(3, (int)retV.get(5));
	}

	@Test
	public void negative() throws IndexOutOfBoundsException {
		List<Integer> unsorted = new ArrayList<Integer>();
		java1 java = new java1();
		List<Integer> retV = java.funnySort(unsorted);
		assertEquals(0, retV.size());
	}
}
	
