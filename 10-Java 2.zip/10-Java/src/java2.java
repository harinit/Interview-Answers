import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.junit.Test;

public class java2 {
	// Question 2 Time: n, Space: n
	List<Integer> distantODDNumbers(List<Integer> lst) throws IndexOutOfBoundsException {
		List<Integer> oddPos = new ArrayList<Integer>();
		int oddcnt = 0;
		for(int i = 0; i < lst.size(); i++) {
			if(lst.get(i) % 2 == 1) {
				oddcnt++;
				oddPos.add(i);
			}
		}
		if(oddcnt > 1) {
			for(int i = 0; i < oddcnt;i++) {
				int pos = (lst.size() - 1) * i / (oddcnt - 1);
				int temp = lst.get(oddPos.get(i));
				lst.set(oddPos.get(i), lst.get(pos));
				lst.set(pos, temp);
			}
		}
		return lst;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> unsorted = new ArrayList<Integer>();
		
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter num count : ");
		int n = reader.nextInt(); // Scans the next token of the input as an int.
		for(int i = 0; i < n; i++) {
			unsorted.add(reader.nextInt());
		}
		//once finished
		reader.close();
		
		java2 java = new java2();
		List<Integer> retV = java.distantODDNumbers(unsorted);
		System.out.println(retV);
	}

}
