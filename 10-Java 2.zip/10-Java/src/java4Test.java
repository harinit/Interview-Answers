import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class java4Test {
	@Test
	public void positive() throws IndexOutOfBoundsException {
		java4 java = new java4();
		Integer [][]array2D = {{1,0,0,0}, {2,5,0,0}, {3,2,1,0}, {1,3,2,1}};
		List<List<Integer>> arrayList2D = new ArrayList<List<Integer>>();
	    for (int i = 0; i < array2D.length; i++) {
	        List<Integer> eachRecord = new ArrayList<Integer>();
	        for (int j = 0; j < array2D[i].length; j++) {
	            eachRecord.add(array2D[i][j]);
	        }
	        arrayList2D.add(eachRecord);
	    }
	    List<Integer> retV = java.highestSumList(arrayList2D);
		assertEquals(4, retV.size());
		assertEquals(1, (int)retV.get(0));
		assertEquals(5, (int)retV.get(1));
		assertEquals(2, (int)retV.get(2));
		assertEquals(3, (int)retV.get(3));
	}
	@Test
	public void negative() throws IndexOutOfBoundsException {
		java4 java = new java4();
		List<List<Integer>> arrayList2D = new ArrayList<List<Integer>>();
	    
	    List<Integer> retV = java.highestSumList(arrayList2D);
		assertEquals(0, retV.size());
		
	}
}
