

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;


// I can't find issue.

public class java3 {

	// Question 3 Time: n, Space: n
	Boolean isAnagram(String a, String b, int x) throws IndexOutOfBoundsException {
		//if(a.length() != b.length())
		//	return false;
		char tempA[] = a.toLowerCase().toCharArray();
		char tempB[] = b.toLowerCase().toCharArray();
		int tA1[] = new int[tempA.length];
		int tA2[] = new int[tempA.length];
		int tB[] = new int[tempB.length];
		int xx = 0, y = 0;
		for(int i = 0; i < tempA.length;i++) {
			if(tempA[i] != ' ') {
				tA1[xx] = (tempA[i] - 'a' + 26 + x) % 26;
				tA2[xx] = (tempA[i] - 'a' + 26 - x) % 26;
				xx++;
			}
		}
		
		for(int i = 0; i < tempB.length;i++) {
			if(tempB[i] != ' ') {
				tB[y] = tempB[i] - 'a';
				y++;
			}
		}
		if(xx != y)
			return false;
		
		for(int i = 0; i < xx - 1; i++) {
			for(int j = i + 1; j < xx; j++) {
				if(tA1[i] > tA1[j]) {
					int temp = tA1[i];
					tA1[i] = tA1[j];
					tA1[j] = temp;
				}
				if(tA2[i] > tA2[j]) {
					int temp = tA2[i];
					tA2[i] = tA2[j];
					tA2[j] = temp;
				}
				if(tB[i] > tB[j]) {
					int temp = tB[i];
					tB[i] = tB[j];
					tB[j] = temp;
				}
			}
		}
		
		int equalFlag = 1;
		for(int i = 0; i < xx; i++) {
			if(tA1[i] != tB[i]) {
				equalFlag = 0;
				break;
			}
		}
		if(equalFlag == 1)
			return true;
		equalFlag = 1;

		for(int i = 0; i < xx; i++) {
			if(tA2[i] != tB[i]) {
				equalFlag = 0;
				break;
			}
		}
		if(equalFlag == 1)
			return true;
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> unsorted = new ArrayList<Integer>();
		
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		String a1 = reader.nextLine();
		String a2 = reader.nextLine();
		int n = reader.nextInt(); // Scans the next token of the input as an int.
		
		reader.close();
		
		java3 java = new java3();
		Boolean retV = java.isAnagram(a1,a2,n);
		System.out.println(retV);
	}
}
