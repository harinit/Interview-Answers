import static org.junit.Assert.*;

import org.junit.Test;

public class java3Test {

	// Question3 Test
	@Test
	public void positive() throws IndexOutOfBoundsException {
		java3 java = new java3();
		// Positive
		assertEquals(true, java.isAnagram("zzcz", "aaad", -1));
		assertEquals(true, java.isAnagram("aaad", "zzcz", -1));
		assertEquals(true, java.isAnagram("Jonathan Smith", "Mith Than Jonas", 0));
	}

	
	@Test
	public void negative() throws IndexOutOfBoundsException {
		java3 java = new java3();
		// Negative
		assertEquals(false, java.isAnagram("aaad", "zzcz", 2));
		assertEquals(false, java.isAnagram("aadc", "dcda", -1));
	}
}
