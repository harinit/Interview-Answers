import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class java4 {

	// Question 4 Time: n*n, Space: n*n
	List<Integer> highestSumList(List<List<Integer>> lst) throws IndexOutOfBoundsException {
		
		List<Integer> retV = new ArrayList<Integer>();
		if(lst.size() == 0)
			return retV;
		List<List<Integer>> parentV = new ArrayList<List<Integer>>();
		List<List<Integer>> vals = new ArrayList<List<Integer>>();
		for(int i = 0; i < lst.size(); i++) {
	        List<Integer> eachRecord = new ArrayList<Integer>();
	        List<Integer> each2 = new ArrayList<Integer>();
	        for (int j = 0; j < lst.size(); j++) {
	        	each2.add(lst.get(i).get(j));
	            eachRecord.add(0);
	        }// ?// I just need test case for 3 rd program
	        vals.add(each2);
	        parentV.add(eachRecord);
		}// I have added. please check.
		for(int i = 1; i < lst.size(); i++) {
			for(int j = 0; j <= i; j++) {
				if(j == 0) {
					vals.get(i).set(j, vals.get(i-1).get(j) + vals.get(i).get(j));
					parentV.get(i).set(j, j);
				} else {
					if(vals.get(i-1).get(j-1) > vals.get(i-1).get(j)) {
						vals.get(i).set(j, vals.get(i-1).get(j - 1) + vals.get(i).get(j));
						parentV.get(i).set(j, j - 1);
					} else {
						vals.get(i).set(j, vals.get(i-1).get(j) + vals.get(i).get(j));
						parentV.get(i).set(j, j);
					}
				}
			}
		}
		int max = -1, maxid = 0;
		for(int i = 0; i < lst.size(); i++) {
			if(max < vals.get(lst.size() - 1).get(i)) {
				max = vals.get(lst.size() - 1).get(i);
				maxid = i;
			}
		}
		retV.add(lst.get(lst.size() - 1).get(maxid));
		
		for(int i = lst.size() - 1; i > 0; i--) {
			retV.add(0, lst.get(i - 1).get(parentV.get(i).get(maxid)));
			maxid = parentV.get(i).get(maxid);
		}
		return retV;
	} 

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> unsorted = new ArrayList<Integer>();
		
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter num count : ");
		int n = reader.nextInt();
		List<List<Integer>> arrayList2D = new ArrayList<List<Integer>>();
	    for (int i = 0; i < n; i++) {
	        List<Integer> eachRecord = new ArrayList<Integer>();
	        for (int j = 0; j < n; j++) {
	            eachRecord.add(reader.nextInt());
	        }
	        arrayList2D.add(eachRecord);
	    }
	    java4 java = new java4();
	    List<Integer> retV = java.highestSumList(arrayList2D);
		System.out.println(retV);
	}
}
