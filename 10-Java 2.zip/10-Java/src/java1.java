
import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

public class java1 {
	// Question 1 Time: n*n, Space: n
	List<Integer> funnySort(List<Integer> unsorted) throws IndexOutOfBoundsException{
		List<Integer> retV = new ArrayList<Integer>();
		
		for(int i = 0; i < unsorted.size() - 1; i++) {
			for(int j = i + 1; j < unsorted.size(); j++) {
				if(unsorted.get(i) > unsorted.get(j)) {
					int temp = unsorted.get(i);
					unsorted.set(i, unsorted.get(j));
					unsorted.set(j, temp);
				}
			}
		}
		int spos = 0, fpos = unsorted.size() - 1;
		for(int i = 0; i < unsorted.size(); i++)
		{
			if(i % 4 == 0 || i % 4 == 1) {
				retV.add(unsorted.get(fpos));
				fpos--;
			} else {
				retV.add(unsorted.get(spos));
				spos++;
			}
		}
		return retV;
	}
	
	public static void main(String[] args) {

		List<Integer> unsorted = new ArrayList<Integer>();
		
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter num count : ");
		int n = reader.nextInt(); // Scans the next token of the input as an int.
		for(int i = 0; i < n; i++) {
			unsorted.add(reader.nextInt());
		}
		//once finished
		reader.close();
		
		java1 java = new java1();
		List<Integer> retV = java.funnySort(unsorted);
		System.out.println(retV);
	}
}
