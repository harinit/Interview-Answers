import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class java2Test {

	// Question2 Test
	@Test
	public void test1() throws IndexOutOfBoundsException {
		List<Integer> unsorted = new ArrayList<Integer>();
		unsorted.add(4);
		unsorted.add(3);
		unsorted.add(5);
		unsorted.add(2);
		unsorted.add(3);
		unsorted.add(8);
		java2 java = new java2();
		List<Integer> retV = java.distantODDNumbers(unsorted);
		assertEquals(6, retV.size());
		assertEquals(3, (int)retV.get(0));
		assertEquals(4, (int)retV.get(1));
		assertEquals(5, (int)retV.get(2));
		assertEquals(2, (int)retV.get(3));
		assertEquals(8, (int)retV.get(4));
		assertEquals(3, (int)retV.get(5));
		
	}

	@Test
	public void test2() throws IndexOutOfBoundsException {
		List<Integer> unsorted2 = new ArrayList<Integer>();
		
		unsorted2.add(9);
		unsorted2.add(2);
		unsorted2.add(3);
		unsorted2.add(3);
		unsorted2.add(4);
		java2 java = new java2();
		List<Integer> retV2 = java.distantODDNumbers(unsorted2);
		assertEquals(5, retV2.size());
		assertEquals(9, (int)retV2.get(0));
		assertEquals(2, (int)retV2.get(1));
		assertEquals(3, (int)retV2.get(2));
		assertEquals(4, (int)retV2.get(3));
		assertEquals(3, (int)retV2.get(4));
	}
}
