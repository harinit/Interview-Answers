import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

public class java5Test {
	
	@Test
	public void positive() throws IndexOutOfBoundsException {
		java5 java = new java5();
		
		// Positive
	    List<Integer> retV = java.sumOfPrimes(9);
	    // System.out.println(retV);
		assertEquals(2, retV.size());
		assertEquals(7, (int)retV.get(0));
		assertEquals(2, (int)retV.get(1));

		// Positive
	    List<Integer> retV2 = java.sumOfPrimes(5);
	    // System.out.println(retV2);
		assertEquals(2, retV2.size());
		assertEquals(3, (int)retV2.get(0));
		assertEquals(2, (int)retV2.get(1));
	}
	
	@Test
	public void negative() throws IndexOutOfBoundsException {
		java5 java = new java5();
		
		// Negative
	    List<Integer> retV1 = java.sumOfPrimes(6);
	    // System.out.println(retV1);
		assertEquals(0, retV1.size());

	}
}
